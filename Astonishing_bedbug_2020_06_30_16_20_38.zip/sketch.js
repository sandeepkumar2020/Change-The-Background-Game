var r=0;
var b= 255;
var g= 100;
function setup() {
  createCanvas(500, 500);
}

function draw() {
  r =  map(mouseX , 0 , 600 ,0,255);
  b =  map(mouseX , 0 , 600 ,255,0);
  g =  map(mouseX , 0 , 600 ,255,0);
  
 
  background(r , g ,b);
  fill(255,255,0);
  ellipse(mouseX,200,60,60);
  
  
}